package com.wsn18748.occudetect;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;


public class MeetFragment extends Fragment {
    private View view;
    private String title;
    private static RecyclerView recyclerView;

    public MeetFragment() {}


    @SuppressLint("ValidFragment")
    public MeetFragment(String title) {
        this.title = title;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_meet, container, false);

        setRecyclerView();
        return view;
    }


    //Setting recycler view
    private void setRecyclerView() {

        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity())); //Linear Items

        ArrayList<Card> arrayList = new ArrayList<>();

        // add cards to recycler view
        arrayList.add(new Card(R.drawable.roboclub, getResources().getString(R.string.roboclub), 50, "Roboclub"));
        arrayList.add(new Card(R.drawable.cic, "Demo Location", 30, "Demo"));

        RecyclerViewAdapter adapter = new RecyclerViewAdapter(getActivity(), arrayList);
        recyclerView.setAdapter(adapter);
    }
}