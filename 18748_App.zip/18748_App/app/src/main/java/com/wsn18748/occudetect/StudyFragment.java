package com.wsn18748.occudetect;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;


public class StudyFragment extends Fragment {
    private View view;
    private String title;
    private static RecyclerView recyclerView;

    public StudyFragment() {}


    @SuppressLint("ValidFragment")
    public StudyFragment(String title) {
        this.title = title;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_study, container, false);

        setRecyclerView();
        return view;
    }


    //Setting recycler view
    private void setRecyclerView() {

        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity())); //Linear Items

        ArrayList<Card> arrayList = new ArrayList<>();

        // add cards to recycler view
        arrayList.add(new Card(R.drawable.sorrells, getResources().getString(R.string.sorrells), 100, "Sorrells"));
        arrayList.add(new Card(R.drawable.gates3, getResources().getString(R.string.gates3), 100, "Gates3"));
        arrayList.add(new Card(R.drawable.hunt3, getResources().getString(R.string.hunt3), 100, "sorrels"));
        arrayList.add(new Card(R.drawable.tartancollab, getResources().getString(R.string.tartan_commons), 100, "sorrels"));
        arrayList.add(new Card(R.drawable.gradlounge, getResources().getString(R.string.grad_lounge), 100, "sorrels"));

        RecyclerViewAdapter adapter = new RecyclerViewAdapter(getActivity(), arrayList);
        recyclerView.setAdapter(adapter);
    }
}