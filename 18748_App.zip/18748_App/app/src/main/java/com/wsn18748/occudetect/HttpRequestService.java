package com.wsn18748.occudetect;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.android.volley.RequestQueue;

import java.util.Timer;
import java.util.TimerTask;

public class HttpRequestService extends Service {

    private Timer timer = new Timer();
    private TimerTask task;
    private boolean firstTimeCalled = true;
    private String locationID = null;
    private String queryType = null;

    private static String TAG = "HTTP Service";
    private String serverUrl = "http://3e250a62.ngrok.io";

    private RequestQueue requestQueue;
    private StringRequest stringRequest;
    private static final String REQUEST_TAG = "request";


    private static int MILLIS_PER_SEC = 1000;

    private static final int delaySecs = 1;
    private static final int delayMillis = delaySecs * MILLIS_PER_SEC;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        timer.scheduleAtFixedRate(task = new TimerTask() {
            @Override
            public void run() {
                buildHttpRequest();
            }
        }, 0, delayMillis);

        Log.i(TAG, "HTTP service started");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (requestQueue != null)
            requestQueue.cancelAll(REQUEST_TAG);

        timer.cancel();
        task.cancel();
        firstTimeCalled = true;
        Log.i(TAG, "HTTP service stopped");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        locationID = (String) intent.getExtras().get("loc"); // get location argument for http call
        Log.i(TAG, locationID);
        firstTimeCalled = true;
        return super.onStartCommand(intent, flags, startId);
    }

    // send http request with volley library
    public void sendHttpRequestToServer(String url) {
        requestQueue = Volley.newRequestQueue(this);
        stringRequest = new StringRequest(com.android.volley.Request.Method.GET, url, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i(TAG, "Message success: " + response.toString());
                sendResponseToActivity(response.toString());
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i(TAG, "Error: " + error.toString());
            }
        });

        stringRequest.setTag(REQUEST_TAG);
        requestQueue.add(stringRequest);
    }

    private void sendResponseToActivity(String msg) {
        Intent intent = new Intent("intentKey");

        intent.putExtra("query", queryType);
        intent.putExtra("intentMsg", msg);
        LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);
    }

    private static String getUrl(String url, String loc, String query) {
        return url + "/18748_get.php/?locationID=" + loc + "&query=" + query;
    }

    private void buildHttpRequest() {
        // send history information the first time called
        if (firstTimeCalled) {
            firstTimeCalled = false;

            if (locationID == null) {
                return;
            }

            String fullUrl = getUrl(serverUrl, locationID, "hist");
            sendHttpRequestToServer(fullUrl);
            queryType = "hist";
        }

        else {
            String fullUrl = getUrl(serverUrl, locationID, "rt");
            sendHttpRequestToServer(fullUrl);
            queryType = "rt";
        }
    }

}