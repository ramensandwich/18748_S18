package com.wsn18748.occudetect;

import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static String TAG = "MainActivity";
    static final int DIALOG_ID = 0;

    private static Toolbar toolbar;
    private static TabLayout tabLayout;
    private static ViewPager viewPager;

    private Character hour;
    private String day;
    private RequestQueue requestQueue;
    private StringRequest stringRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupViewPager();
        setupToolbar();
        setupTablayout();


        FloatingActionButton fab = findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                View mView = getLayoutInflater().inflate(R.layout.day_time_dialog, null);
                builder.setTitle("Select day and time");

                final Spinner daySpinner = (Spinner) mView.findViewById(R.id.spinnerDay);
                final Spinner timeSpinner = (Spinner) mView.findViewById(R.id.spinnerTime);

                ArrayAdapter<String> dayAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item,
                        getResources().getStringArray(R.array.daysList));
                dayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                daySpinner.setAdapter(dayAdapter);

                ArrayAdapter<String> timeAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_item,
                        getResources().getStringArray(R.array.timeList));
                timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                timeSpinner.setAdapter(timeAdapter);

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String timeVal = timeSpinner.getSelectedItem().toString();
                        hour = timeVal.charAt(0);
                        day = daySpinner.getSelectedItem().toString();

                        String recURL = getUrl(day, hour);
                        getRecFromServer(recURL);

                        Log.d(TAG, "time: " + hour + " day: " + day);
                        dialog.dismiss();
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                builder.setView(mView);
                AlertDialog dialog = builder.create();
                dialog.show();

            }
        });

    }


    private static String getUrl(String day, Character hour) {
        return "http://3e250a62.ngrok.io/18748_get.php/?day=" + day + "&hour=" + hour + "&query=rec";
    }

    // send http request with volley library
    private void getRecFromServer(String url) {
        RequestQueue queue = Volley.newRequestQueue(this);

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("REC RESPONSE", response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("REC RESPONSE","That didn't work!");
            }
        });

        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

    private void setupViewPager() {
        viewPager = (ViewPager) findViewById(R.id.view_pager);
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFrag(new StudyFragment("Study"), "Study");
        adapter.addFrag(new EatFragment("Eat"), "Eat");
        adapter.addFrag(new MeetFragment("Meet"), "Meet");
        viewPager.setAdapter(adapter);
    }


    private void setupTablayout(){

        tabLayout = findViewById(R.id.tab_layout);

        if(tabLayout == null)
            return;

        tabLayout.setupWithViewPager(viewPager);
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());//setting current selected item over viewpager
                switch (tab.getPosition()) {
                    case 0:
                        Log.e("TAG","Study Tab");
                        break;
                    case 1:
                        Log.e("TAG","Eat Tab");
                        break;
                    case 2:
                        Log.e("TAG","Meet Tab");
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }


    private void setupToolbar(){
        toolbar = findViewById(R.id.toolbar);
        if(toolbar != null)
            setSupportActionBar(toolbar);

        // Show menu icon and add our logo
        final ActionBar ab = getSupportActionBar();
        ab.setDisplayShowTitleEnabled(true);
        ab.setTitle("  ScottySeats");

        ab.setIcon(R.drawable.ic_logo);
    }

    // View Pager fragments setting adapter class
    // Source: http://www.androhub.com/android-material-design-tabs-using-tablayout
    private class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> fragmentList = new ArrayList<>();//fragment arraylist
        private final List<String> fragmentTitleList = new ArrayList<>();//title arraylist

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

        //adding fragments and title method
        public void addFrag(Fragment fragment, String title) {
            fragmentList.add(fragment);
            fragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return fragmentTitleList.get(position);
        }
    }

}
