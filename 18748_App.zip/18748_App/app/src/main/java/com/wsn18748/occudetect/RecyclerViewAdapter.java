package com.wsn18748.occudetect;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.CardViewHolder> {
    private ArrayList<Card> arrayList;
    private Context context;
    private String TAG = "RV Adapter";

    public RecyclerViewAdapter(Context context, ArrayList<Card> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @Override
    public int getItemCount() {
        return (null != arrayList ? arrayList.size() : 0);
    }

    @Override
    public void onBindViewHolder(CardViewHolder holder, int position) {
        final CardViewHolder mainHolder = (CardViewHolder) holder;

        //Setting text over text view
        mainHolder.title.setText(arrayList.get(position).getTitle());

        // Setting image over image view
        mainHolder.imageView.setImageResource(arrayList.get(position).getImageID());
    }

    @Override
    public CardViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.card_layout, viewGroup, false);
        CardViewHolder viewHolder = new CardViewHolder(view);
        return viewHolder;
    }

    public class CardViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        public TextView title;
        public ImageView imageView;


        public CardViewHolder(View view) {
            super(view);
            this.title = (TextView) view.findViewById(R.id.card_title);
            this.imageView = (ImageView) view.findViewById(R.id.card_image);
            this.cardView = (CardView) view.findViewById(R.id.card);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    final Intent intent;
                    int position = getAdapterPosition();

                    // Pass card to new activity
                    intent = new Intent(view.getContext(), DetailActivity.class);
                    intent.putExtra(DetailActivity.EXTRA_CARD, arrayList.get(position));

                    String transitionName = view.getContext().getResources().getString(R.string.transition_image);
                    ActivityOptionsCompat options = ActivityOptionsCompat.
                            makeSceneTransitionAnimation((Activity)view.getContext(),
                                    (View)cardView, transitionName);
                    view.getContext().startActivity(intent, options.toBundle());
                }
            });

        }
    }
}