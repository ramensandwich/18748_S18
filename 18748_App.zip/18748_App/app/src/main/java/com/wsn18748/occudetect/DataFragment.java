package com.wsn18748.occudetect;


import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class DataFragment extends Fragment {
    private View view;
    private String title;
    private Context context;
    private Intent intent;
    private BarChart chart;


    private static String TAG = "DataFragment";


    public DataFragment() {
    }

    @SuppressLint("ValidFragment")
    public DataFragment(String title) {
        this.title = title;
        }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_data,container,false);

        chart = (BarChart) view.findViewById(R.id.bar_chart);

//        int[] intArray = new int[] {5,0,0,0,0,0,0,1,5,10,11,22,35,40,45,46,57,48,49,32,31,32,23,14};
//        BarChartUtil.drawChart(getContext(), chart, intArray, 17, 30, 10);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
    }


    public static int getAvg(int[] inputArray){
        int avg = 0;
        for(int i = 0; i < inputArray.length; i++){
            avg += inputArray[i];
        }

        avg = (int)(avg/inputArray.length);
        return avg;
    }


    public void hi(String str) {
        Log.d(TAG, str);
    }

    public void drawChartFromActivity(int[] visits, int currTimeIndex, int currTimeVisits,
                                      int maxCapacity) {
        int avgCapacity = getAvg(visits);
        BarChartUtil.drawChart(getContext(), chart, visits, maxCapacity, avgCapacity, currTimeIndex, currTimeVisits);
    }




}
