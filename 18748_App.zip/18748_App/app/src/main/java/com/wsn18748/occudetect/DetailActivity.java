package com.wsn18748.occudetect;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.provider.ContactsContract;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.BroadcastReceiver;

import org.json.JSONArray;
import org.json.JSONObject;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class DetailActivity extends AppCompatActivity {
    private Card card;
    private ImageView imageView;
    private TextView titleTextView;
    private Context context;
    private Intent intent;
    private static Toolbar toolbar;
    private static TabLayout tabLayout;
    private static ViewPager viewPager;
    private DetailActivity.ViewPagerAdapter adapter;

    public static final String EXTRA_CARD = "intent_card";

    private static String TAG = "DetailActivity";

    // Card variables
    private int maxCapacity = 0;
    private String httpName;

    // Used to parse JSON ARRAY
    private int SUN_INDEX = 0;
    private int MON_INDEX = 1;
    private int TUES_INDEX = 2;
    private int WED_INDEX = 3;
    private int THURS_INDEX = 4;
    private int FRI_INDEX = 5;
    private int SAT_INDEX = 6;

    // Used to parse JSON OBJECT
    private String SUN_STR = "Sun";
    private String MON_STR = "Mon";
    private String TUES_STR = "Tue";
    private String WED_STR = "Wed";
    private String THURS_STR = "Thu";
    private String FRI_STR = "Fri";
    private String SAT_STR = "Sat";

    // JSON Structures
    private JSONArray jsonArrHTTPReply = null;
    private JSONObject jsonObjHTTPReply = null;


    private JSONObject jsonSUN = null;
    private JSONObject jsonMON = null;
    private JSONObject jsonTUES = null;
    private JSONObject jsonWED = null;
    private JSONObject jsonTHURS = null;
    private JSONObject jsonFRI = null;
    private JSONObject jsonSAT = null;


    private String mockDataStr = "[{\"Sun\":[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null]},{\"Mon\":[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null]},{\"Tue\":[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null]},{\"Wed\":[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null]},{\"Thu\":[null,null,null,null,null,null,null,null,null,null,null,null,null,\"4\",\"4\",null,null,null,null,null,null,null,null,null]},{\"Fri\":[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null]},{\"Sat\":[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null]}]";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        setupViewPager();
        setupTablayout();
        setupToolbar();

        card = getIntent().getExtras().getParcelable(EXTRA_CARD);

        // get values
        maxCapacity = card.getMaxCap();
        httpName = card.getHTTPName();

        // reference views
        imageView = findViewById(R.id.activity_image);
        titleTextView = findViewById(R.id.title_text);

        titleTextView.setText(card.getTitle());
        imageView.setImageResource(card.getImageID());

    }


    @Override
    protected void onResume() {
        super.onResume();
        context = getApplicationContext();
        intent = new Intent(context, HttpRequestService.class);
        intent.putExtra("loc", httpName);
        startService(intent);

        LocalBroadcastManager.getInstance(context).registerReceiver(
                broadcastReceiver, new IntentFilter("intentKey"));

    }

    @Override
    protected void onStop() {
        super.onStop();
        if(intent != null) {
            stopService(intent);
        }

        if (broadcastReceiver != null) {
            LocalBroadcastManager.getInstance(context).unregisterReceiver(broadcastReceiver);
        }
    }


    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String message = intent.getStringExtra("intentMsg");
            String queryType = intent.getStringExtra("query");

            if (queryType.equals("hist")) {

                Log.d(TAG, "Received historical data");

                // Convert received string to json objects
                try {
                    jsonArrHTTPReply = new JSONArray(message);
                    Log.d(TAG, jsonArrHTTPReply.toString());

                    jsonSUN = jsonArrHTTPReply.getJSONObject(SUN_INDEX);
                    jsonMON = jsonArrHTTPReply.getJSONObject(MON_INDEX);
                    jsonTUES = jsonArrHTTPReply.getJSONObject(TUES_INDEX);
                    jsonWED = jsonArrHTTPReply.getJSONObject(WED_INDEX);
                    jsonTHURS = jsonArrHTTPReply.getJSONObject(THURS_INDEX);
                    jsonFRI = jsonArrHTTPReply.getJSONObject(FRI_INDEX);
                    jsonSAT = jsonArrHTTPReply.getJSONObject(SAT_INDEX);

                    buildGraph(jsonSUN, jsonObjHTTPReply, SUN_INDEX, SUN_STR);

                } catch (Throwable t) {
                    Log.e(TAG, "Err: JSON parsing failed: \"" + message + "\"");
                }

            } else {

                Log.d(TAG, "Received current data");
                // Receive: "{\"day\"=Fri,\"hour\"=08,\"num_people\"=72}"
                // need to remove bookend quotes and backslashes
                message = message.replaceAll("^\"|\"$", "");
                message = message.replaceAll("\\\\", "");

                try {
                    jsonObjHTTPReply = new JSONObject(message);
                    Log.d(TAG, jsonObjHTTPReply.toString());

                    String day = jsonObjHTTPReply.getString("day");

                    if (day.equals(SUN_STR))
                        buildGraph(jsonSUN, jsonObjHTTPReply, SUN_INDEX, SUN_STR);

                    else if (day.equals(MON_STR))
                        buildGraph(jsonMON, jsonObjHTTPReply, MON_INDEX, MON_STR);

                    else if (day.equals(TUES_STR))
                        buildGraph(jsonTUES, jsonObjHTTPReply, TUES_INDEX, TUES_STR);

                    else if (day.equals(WED_STR))
                        buildGraph(jsonWED, jsonObjHTTPReply, WED_INDEX, WED_STR);

                    else if (day.equals(THURS_STR))
                        buildGraph(jsonTHURS, jsonObjHTTPReply, THURS_INDEX, THURS_STR);

                    else if (day.equals(FRI_STR))
                        buildGraph(jsonFRI, jsonObjHTTPReply, FRI_INDEX, FRI_STR);

                    else
                        buildGraph(jsonSAT, jsonObjHTTPReply, SAT_INDEX, SAT_STR);


                } catch (Throwable t) {
                    Log.e(TAG, "Err: JSON parsing failed: \"" + message + "\"");
                }

            }
        }
    };

    private void setupToolbar(){
        toolbar = findViewById(R.id.toolbar_detail);
        if(toolbar != null)
            setSupportActionBar(toolbar);

        // Show menu icon and add our logo
        final ActionBar ab = getSupportActionBar();
        ab.setDisplayShowTitleEnabled(false); // don't show app name
        ab.setDisplayHomeAsUpEnabled(true); // set back button; back action specified in manifest
    }

    // Set up view pager with week tags
    private void setupViewPager() {
        viewPager = (ViewPager) findViewById(R.id.view_pager_detail);
        adapter = new DetailActivity.ViewPagerAdapter(getSupportFragmentManager());

        // get relevant JSON data (historical visits) to pass to fragment
        adapter.addFrag(new DataFragment("Su"), "Su ");
        adapter.addFrag(new DataFragment("M"), "M");
        adapter.addFrag(new DataFragment("Tu"), "Tu");
        adapter.addFrag(new DataFragment("W"), "W");
        adapter.addFrag(new DataFragment("Th"), "Th");
        adapter.addFrag(new DataFragment("F"), "F");
        adapter.addFrag(new DataFragment("Sa"), "Sa");

        viewPager.setAdapter(adapter);
    }


    private int[] buildIntArrayFromJsonArray(JSONArray jsonVisits) {
        int[] intArray = new int[jsonVisits.length()];

        if (jsonVisits == null) {
            Log.e(TAG, "jsonVisits in buildInt is null");
            return new int[24];
        }

        for (int i = 0; i < intArray.length; ++i) {
            intArray[i] = jsonVisits.optInt(i);
        }

        Log.d(TAG, "Int array: " + Arrays.toString(intArray));
        return intArray;
    }

    public void buildGraph(JSONObject jsonHistDay, JSONObject jsonCur, int dayIndex,
                           String dayStr) {
        JSONArray jsonVisits = null;
        int curTimeIndex;
        int curTimeVisits;
        String curDay;

        if (jsonHistDay == null) {
            Log.e(TAG, "History data is null");
            return;
        }

        try {
            // get json visits array
            jsonVisits = jsonHistDay.getJSONArray(dayStr);

            if (jsonCur != null && jsonCur.getString("day").equals(dayStr)) {
                curTimeIndex = jsonCur.getInt("hour");
                curTimeVisits = jsonCur.getInt("num_people");
            } else {
                curTimeIndex = -1;
                curTimeVisits = 0;
            }

        } catch (Throwable t) {
            Log.e(TAG, "Err: JSON ARRAY parsing failed: " + dayStr);
            return;
        }

        if (jsonVisits == null) return;

        int[] visitsArray = buildIntArrayFromJsonArray(jsonVisits);


        DataFragment dataFrag = (DataFragment) adapter.getItem(dayIndex);
        dataFrag.drawChartFromActivity(visitsArray, curTimeIndex, curTimeVisits, maxCapacity);
    }


//    private int[] getVisitsArray(String day) {
//        int[] intArray;
//
//        try {
//            // get json array and convert to int array
//            JSONArray jsonVisits = jsonHTTPReply.getJSONArray(day);
////            intArray = new int[jsonVisits.length()];
////            for (int i = 0; i < intArray.length; ++i) {
////                intArray[i] = jsonVisits.optInt(i);
////            }
//
//            Log.d(TAG, "SUCCESS for " + day + ": " + jsonVisits.toString());
//
//        } catch (Throwable t) {
//            intArray = new int[24]; // array of 0s
//            Log.e(TAG, "Err: JSON ARRAY parsing failed: " + day);
//        }
//
////        return intArray;
//    }

    // Set up 7 tabs for graphs for each day of the week
    private void setupTablayout(){

        tabLayout = findViewById(R.id.tab_layout_detail);

        if(tabLayout == null)
            return;

        tabLayout.setupWithViewPager(viewPager);
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition()); //setting current selected item over viewpager

                switch (tab.getPosition()) {
                    case 0:
                        buildGraph(jsonSUN, jsonObjHTTPReply, SUN_INDEX, SUN_STR);
                        break;
                    case 1:
                        buildGraph(jsonMON, jsonObjHTTPReply, MON_INDEX, MON_STR);
                        break;
                    case 2:
                        buildGraph(jsonTUES, jsonObjHTTPReply, TUES_INDEX, TUES_STR);
                        break;
                    case 3:
                        buildGraph(jsonWED, jsonObjHTTPReply, WED_INDEX, WED_STR);
                        break;
                    case 4:
                        buildGraph(jsonTHURS, jsonObjHTTPReply, THURS_INDEX, THURS_STR);
                        break;
                    case 5:
                        buildGraph(jsonFRI, jsonObjHTTPReply, FRI_INDEX, FRI_STR);
                        break;
                    case 6:
                        buildGraph(jsonSAT, jsonObjHTTPReply, SAT_INDEX, SAT_STR);
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    // View Pager fragments setting adapter class
    // Source: http://www.androhub.com/android-material-design-tabs-using-tablayout
    private class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> fragmentList = new ArrayList<>(); //fragment array list
        private final List<String> fragmentTitleList = new ArrayList<>(); //title array list

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

        //adding fragments and title method
        public void addFrag(Fragment fragment, String title) {
            fragmentList.add(fragment);
            fragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return fragmentTitleList.get(position);
        }
    }

}
