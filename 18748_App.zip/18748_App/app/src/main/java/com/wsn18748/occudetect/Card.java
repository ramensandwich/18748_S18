package com.wsn18748.occudetect;

import android.os.Parcel;
import android.os.Parcelable;

public class Card implements Parcelable {
    private int imageID;
    private String title;
    private String httpName;
    private int maxCap;

    // Constructor
    public Card(int imageID, String title, int maxCap, String httpName) {
        this.imageID = imageID;
        this.title = title;
        this.httpName = httpName;
        this.maxCap = maxCap;
    }

    // Get and set methods
    public int getImageID() {
        return imageID;
    }

    public void setImageID(int imgID) {
        this.imageID = imageID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setMaxCap(int maxCap) { this.maxCap = maxCap; }

    public int getMaxCap() { return maxCap; }

    public void setHTTPName(String httpName) { this.httpName = httpName; }

    public String getHTTPName() { return httpName; }

    // Parcelling
    public Card(Parcel in) {
        this.imageID = in.readInt();
        this.title = in.readString();
        this.maxCap = in.readInt();
        this.httpName = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.imageID);
        dest.writeString(this.title);
        dest.writeInt(this.maxCap);
        dest.writeString(this.httpName);
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        public Card createFromParcel(Parcel in) {
            return new Card(in);
        }

        public Card[] newArray(int size) {
            return new Card[size];
        }
    };

}
