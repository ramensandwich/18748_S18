package com.wsn18748.occudetect;

import android.content.Context;
import android.util.Log;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.IMarker;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BarChartUtil {

    private static int textSize = 10;
    private static String TAG = "BarChart";


    private static BarDataSet getBarDataSet(Context context, int[] visits, int currTimeIndex, int currTimeVisits) {
        int[] barColors = new int[visits.length + 1]; // add one for the currTime
        int barColorIndex = 0;
        List<BarEntry> yVals = new ArrayList<>();

        int historicalVisitsColor = context.getResources().getColor(R.color.colorAccentTab);
        int currentVisitsColor = context.getResources().getColor(R.color.colorAccent);
        int historicalVisitsBehindColor = context.getResources().getColor(R.color.colorBarChartTrans);

        for (int i = 0; i < visits.length; i++) {
            List<BarEntry> yValsForBar = new ArrayList();


            if (i == currTimeIndex) { // at x axis spot where current visits should be placed
                yValsForBar.add(new BarEntry(i, currTimeVisits));
                barColors[barColorIndex] = currentVisitsColor;
                barColorIndex++;

                yValsForBar.add(new BarEntry(i, visits[i]));
                barColors[barColorIndex] = historicalVisitsBehindColor;
                barColorIndex++;

            } else { // add visits normally
                yValsForBar.add(new BarEntry(i, visits[i]));
                barColors[barColorIndex] = historicalVisitsColor;
                barColorIndex++;
            }

            yVals.addAll(yValsForBar);
        }

        BarDataSet set = new BarDataSet(yVals, "BarDataSet");
        set.setColors(barColors);
        return set;
    }

    private static void setXAxisLabels(XAxis xAxis) {
        final ArrayList<String> xLabel = new ArrayList<>();
        for(int i = 1; i < 12; i++) { // 1am to 11am
            xLabel.add(""+ i + " AM");
        }

        xLabel.add("12 PM"); // 12pm

        for(int i = 1; i < 12; i++) { // 12pm to 11pm
            xLabel.add(""+ i + " PM");
        }

        xLabel.add("12 AM"); // 12am

        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                return xLabel.get((int)value);
            }
        });
    }


    public static void drawChart(final Context context, BarChart chart, int[] dataIntArray, int maxCapacity,
                                 int avgCapacity, int currTimeIndex, int currTimeVisits) {
        BarDataSet set = getBarDataSet(context, dataIntArray, currTimeIndex, currTimeVisits); // convert data to a bar data struct
        BarData data = new BarData(set);

        set.setHighlightEnabled(true);

        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);

        xAxis.setDrawLabels(true);
        xAxis.setDrawAxisLine(true);
        xAxis.setAxisLineWidth(0);  // x axis line size

        xAxis.setAxisLineColor(context.getResources().getColor(R.color.colorLightText));
        xAxis.setDrawGridLines(false);
        xAxis.setTextSize(textSize);
        xAxis.setTextColor(context.getResources().getColor(R.color.colorPrimaryText));

        // set time labels on x axis
        setXAxisLabels(xAxis);

        chart.getAxisRight().setDrawAxisLine(false);
        chart.getAxisRight().setDrawGridLines(false);
        chart.getAxisRight().setDrawLabels(false);

        YAxis yAxis = chart.getAxisLeft();
        yAxis.setEnabled(true);
        yAxis.setDrawGridLines(false);
        yAxis.setDrawLabels(false);
        yAxis.setDrawAxisLine(false);
        yAxis.setTextSize(textSize);
        yAxis.setTextColor(context.getResources().getColor(R.color.colorPrimaryText));
        yAxis.setAxisLineColor(context.getResources().getColor(R.color.colorLightText));
        yAxis.setAxisLineWidth(0);  // y axis line size

        data.setDrawValues(false); // don't draw values above bars
        data.setValueTextColor(context.getResources().getColor(R.color.colorPrimaryText)); //  bar data level
        data.setValueTextSize(12); // bar data size
        data.setBarWidth(0.9f); // set custom bar width (creates space of 0.1f between bars)

        // bar data size
        chart.setData(data);
        chart.getDescription().setText(""); // no description
        chart.invalidate();
        chart.setHorizontalScrollBarEnabled(true);
//        chart.setVisibleXRange(0f, 8f); // limit hours shown
        chart.setFitBars(true); // make the x-axis fit exactly all bars
        chart.getLegend().setEnabled(false);
        chart.setDrawGridBackground(false);
        chart.setDoubleTapToZoomEnabled(false);

        // Reset all limit lines to avoid overlapping lines
        yAxis.removeAllLimitLines();

        // Add maximum value threshold line
        LimitLine maxLL = new LimitLine(maxCapacity, "Max Capacity");
        maxLL.setLineWidth(1f);
        maxLL.setLineColor(context.getResources().getColor(R.color.colorLightText));
        maxLL.enableDashedLine(5f, 10f, 0f);
        maxLL.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_TOP);
        maxLL.setTextSize(10f);
        maxLL.setTextColor(context.getResources().getColor(R.color.colorLightText));
        yAxis.addLimitLine(maxLL);
        yAxis.setDrawLimitLinesBehindData(false);

        // Add average value threshold line
        LimitLine avgLL = new LimitLine(avgCapacity, "Avg Daily");
        avgLL.setLineWidth(1f);
        avgLL.setLineColor(context.getResources().getColor(R.color.colorLightText));
        avgLL.enableDashedLine(5f, 10f, 0f);
        avgLL.setLabelPosition(LimitLine.LimitLabelPosition.RIGHT_TOP);
        avgLL.setTextSize(10f);
        avgLL.setTextColor(context.getResources().getColor(R.color.colorLightText));
        yAxis.addLimitLine(avgLL);
        yAxis.setDrawLimitLinesBehindData(false);

        // Add marker view
        chart.setHighlightPerTapEnabled(true);
        chart.setTouchEnabled(true);
        CustomMarkerView mv = new CustomMarkerView(context, R.layout.marker_layout);
//        mv.setChartView(chart); // For bounds control
        chart.setMarker(mv); // Set the marker to the chart
    }




}
